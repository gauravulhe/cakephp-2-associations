<?php
App::uses('CitiesMember', 'Model');

/**
 * CitiesMember Test Case
 */
class CitiesMemberTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.cities_member',
		'app.city',
		'app.state',
		'app.member'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->CitiesMember = ClassRegistry::init('CitiesMember');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->CitiesMember);

		parent::tearDown();
	}

}
