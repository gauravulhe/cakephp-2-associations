<?php
App::uses('AppController', 'Controller');
/**
 * CitiesMembers Controller
 *
 * @property CitiesMember $CitiesMember
 * @property PaginatorComponent $Paginator
 */
class CitiesMembersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->CitiesMember->recursive = 0;
		$this->set('citiesMembers', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->CitiesMember->exists($id)) {
			throw new NotFoundException(__('Invalid cities member'));
		}
		$options = array('conditions' => array('CitiesMember.' . $this->CitiesMember->primaryKey => $id));
		$this->set('citiesMember', $this->CitiesMember->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->CitiesMember->create();
			if ($this->CitiesMember->save($this->request->data)) {
				$this->Flash->success(__('The cities member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The cities member could not be saved. Please, try again.'));
			}
		}
		$cities = $this->CitiesMember->City->find('list');
		$members = $this->CitiesMember->Member->find('list');
		$this->set(compact('cities', 'members'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->CitiesMember->exists($id)) {
			throw new NotFoundException(__('Invalid cities member'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->CitiesMember->save($this->request->data)) {
				$this->Flash->success(__('The cities member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The cities member could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('CitiesMember.' . $this->CitiesMember->primaryKey => $id));
			$this->request->data = $this->CitiesMember->find('first', $options);
		}
		$cities = $this->CitiesMember->City->find('list');
		$members = $this->CitiesMember->Member->find('list');
		$this->set(compact('cities', 'members'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->CitiesMember->id = $id;
		if (!$this->CitiesMember->exists()) {
			throw new NotFoundException(__('Invalid cities member'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->CitiesMember->delete()) {
			$this->Flash->success(__('The cities member has been deleted.'));
		} else {
			$this->Flash->error(__('The cities member could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
