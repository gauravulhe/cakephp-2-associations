<?php
App::uses('AppController', 'Controller');
/**
 * Members Controller
 *
 * @property Member $Member
 * @property PaginatorComponent $Paginator
 */
class MembersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator',
		'Search.Prg'
	);

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Member->recursive = 0;
		$this->Prg->commonProcess();
		$this->Paginator->settings['conditions'] = $this->Member->parseCriteria($this->Prg->parsedParams());
		//debug($this->Paginator->paginate());
		$this->set('members', $this->Paginator->paginate());
	}

	/**
	 * user match method
	 */
	public function match() {
		$members = $this->Member->find();
		$cities = $members['Member']['cities'];
		$states = $members['Member']['states'];
		$countries = $members['Member']['countries'];

		$this->Member->recursive = 0;
		$conditions = array(
				"Member.city_id IN ($cities)",
				"Member.state_id IN ($states)",
				"Member.country_id IN ($countries)"
		);
		debug($conditions);
		$this->set('members', $this->Paginator->paginate($conditions));
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Member->exists($id)) {
			throw new NotFoundException(__('Invalid member'));
		}
		$options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
		$this->set('member', $this->Member->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$requestData = $this->request->data;

			$country = $requestData['Country']['Country'];
			$requestData['Member']['countries'] = implode(', ', $country);

			$state = $requestData['State']['State'];
			$requestData['Member']['states'] = implode(', ', $state);

			$city = $requestData['City']['City'];
			$requestData['Member']['cities'] = implode(', ', $city);
			$timestamp = strtotime(date('Y-m-d h:m:s'));
			$requestData['Member']['photo'] = $timestamp.'_'.$requestData['Member']['image']['name'];

			$this->Member->create();
			if ($data = $this->Member->save($requestData)) {

				/////////////////////////////////////////////

				$max_size = 200; //max image size in Pixels
				$destination_folder = WWW_ROOT.'img/images';
				$watermark_png_file = WWW_ROOT.'img/images/watermark.png'; //watermark png file
				
				$image_name = $timestamp.'_'.$requestData['Member']['image']['name']; //file name

				$image_size = $requestData['Member']['image']['size']; //file size
				$image_temp = $requestData['Member']['image']['tmp_name']; //file temp
				$image_type = $requestData['Member']['image']['type']; //file type


				switch(strtolower($image_type)){ //determine uploaded image type 
						//Create new image from file
						case 'image/png': 
							$image_resource =  imagecreatefrompng($image_temp);
							break;
						case 'image/gif':
							$image_resource =  imagecreatefromgif($image_temp);
							break;          
						case 'image/jpeg': case 'image/pjpeg':
							$image_resource = imagecreatefromjpeg($image_temp);
							break;
						default:
							$image_resource = false;
					}
				
				if($image_resource){
					//Copy and resize part of an image with resampling
					list($img_width, $img_height) = getimagesize($image_temp);
					
				    //Construct a proportional size of new image
					$image_scale        = min($max_size / $img_width, $max_size / $img_height); 
					$new_image_width    = ceil($image_scale * $img_width);
					$new_image_height   = ceil($image_scale * $img_height);
					$new_canvas         = imagecreatetruecolor($new_image_width , $new_image_height);

					if(imagecopyresampled($new_canvas, $image_resource , 0, 0, 0, 0, $new_image_width, $new_image_height, $img_width, $img_height))
					{
						
						if(!is_dir($destination_folder)){ 
							mkdir($destination_folder);//create dir if it doesn't exist
						}
						
						//center watermark
						$watermark_left = ($new_image_width/2)-(300/2); //watermark left
						$watermark_bottom = ($new_image_height/2)-(100/2); //watermark bottom

						$watermark = imagecreatefrompng($watermark_png_file); //watermark image
						imagecopy($new_canvas, $watermark, $watermark_left, $watermark_bottom, 0, 0, 300, 100); //merge image
						
						//output image direcly on the browser.
						header('Content-Type: image/jpeg');
						imagejpeg($new_canvas, NULL , 90);
						
						//Or Save image to the folder
						imagejpeg($new_canvas, $destination_folder.'/'.$image_name , 90);

						//free up memory
						imagedestroy($new_canvas); 
						imagedestroy($image_resource);
						die();
					}
				}

				////////////////////////////////////////////

				$this->Flash->success(__('The member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The member could not be saved. Please, try again.'));
			}
		}
		$cities = $this->Member->City->find('list', array('fields' => array('id', 'city')));
		$states = $this->Member->State->find('list', array('fields' => array('id', 'state')));
		$countries = $this->Member->Country->find('list', array('fields' => array('id', 'country')));
		$cities = $this->Member->City->find('list', array('fields' => array('id', 'city')));
		$countries = $this->Member->Country->find('list', array('fields' => array('id', 'country')));
		$states = $this->Member->State->find('list', array('fields' => array('id', 'state')));
		$this->set(compact('cities', 'states', 'countries', 'cities', 'countries', 'states'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Member->exists($id)) {
			throw new NotFoundException(__('Invalid member'));
		}
		if ($this->request->is(array('post', 'put'))) {
			$requestData = $this->request->data;

			$country = $requestData['Country']['Country'];
			$requestData['Member']['countries'] = implode(', ', $country);

			$state = $requestData['State']['State'];
			$requestData['Member']['states'] = implode(', ', $state);

			$city = $requestData['City']['City'];
			$requestData['Member']['cities'] = implode(', ', $city);

			//debug($requestData['Member']['countries']);exit;
			if ($this->Member->save($requestData)) {
				$this->Flash->success(__('The member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The member could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
			$this->request->data = $this->Member->find('first', $options);
		}
		$cities = $this->Member->City->find('list', array('fields' => array('id', 'city')));
		$states = $this->Member->State->find('list', array('fields' => array('id', 'state')));
		$countries = $this->Member->Country->find('list', array('fields' => array('id', 'country')));
		$cities = $this->Member->City->find('list', array('fields' => array('id', 'city')));
		$countries = $this->Member->Country->find('list', array('fields' => array('id', 'country')));
		$states = $this->Member->State->find('list', array('fields' => array('id', 'state')));
		$this->set(compact('cities', 'states', 'countries', 'cities', 'countries', 'states'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Member->id = $id;
		if (!$this->Member->exists()) {
			throw new NotFoundException(__('Invalid member'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Member->delete()) {
			$this->Flash->success(__('The member has been deleted.'));
		} else {
			$this->Flash->error(__('The member could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
